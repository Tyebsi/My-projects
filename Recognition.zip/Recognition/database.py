import sqlite3
import cv2

# Step 1: Create a database and connect to it
conn = sqlite3.connect('faces.db')
c = conn.cursor()

# Step 2: Create a table for users
c.execute('''
    CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY,
        name TEXT,
        image BLOB
    )
''')

# Function to insert user into database
def insert_user(name, image_path):
    with open(image_path, 'rb') as file:
        img = file.read()
    c.execute("INSERT INTO users (name, image) VALUES (?, ?)", (name, img))
    conn.commit()

# Example of inserting a user
insert_user('John Doe', 'path_to_face_image.jpg')

# Step 3: Function to retrieve an image from the database
def get_user_image(name):
    c.execute("SELECT image FROM users WHERE name=?", (name,))
    img = c.fetchone()
    if img:
        with open(f'{name}.jpg', 'wb') as file:
            file.write(img[0])

# Close the connection when done
conn.close()